from pydantic import BaseModel
from datetime import date, datetime
from typing import Optional, List


class LigneFactureCreate(BaseModel):
    description: str
    categorie: str
    date_debut: Optional[date] = None
    date_fin: Optional[date] = None
    montant_ht: float


class FactureCreate(BaseModel):
    fournisseur: str
    client: str
    numero_client: str
    numero_facture: str
    type_facture: str
    source_fichier: Optional[str] = None

    numero_abonnement: Optional[str] = None
    numero_appel: Optional[str] = None

    date_facture: date
    mois_facture: Optional[str] = None
    periode_debut: Optional[date] = None
    periode_fin: Optional[date] = None
    date_limite_paiement: Optional[date] = None

    montant_ht: float
    montant_tva: float
    montant_ttc: float
    montant_avance_credit: Optional[float] = 0
    montant_du: Optional[float] = None

    est_duplicata: Optional[bool] = False

    lignes: Optional[List[LigneFactureCreate]] = []


class FactureResponse(FactureCreate):
    id: int
    statut: str
    erreur_validation: Optional[str] = None

    class Config:
        from_attributes = True


class StatutUpdate(BaseModel):
    statut: str
    numero_bc: Optional[str] = None


class LogResponse(BaseModel):
    id: int
    facture_id: int
    etape: str
    niveau: str
    message: str
    date_creation: datetime

    class Config:
        from_attributes = True
class FactureRejetCreate(BaseModel):
    numero_facture: str
    fournisseur: str
    raison: str
    donnees_brutes: dict


class FactureRejetResponse(FactureRejetCreate):
    id: int
    date_rejet: datetime

    class Config:
        from_attributes = True