from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import get_db, init_db

from schemas import FactureCreate, FactureResponse, StatutUpdate, LogResponse, FactureRejetCreate, FactureRejetResponse
from models.database_models import FactureDB, BonDeCommandeDB, LogDB, LigneFactureDB, FactureRejetDB

app = FastAPI(title="API RPA IAM - Marsa Maroc")


@app.on_event("startup")
def startup():
    init_db()



@app.post("/factures/", response_model=FactureResponse)
def creer_facture(facture: FactureCreate, db: Session = Depends(get_db)):
    donnees = facture.dict(exclude={"lignes"})
    nouvelle = FactureDB(**donnees)
    db.add(nouvelle)
    db.commit()
    db.refresh(nouvelle)

    for ligne in facture.lignes:
        nouvelle_ligne = LigneFactureDB(facture_id=nouvelle.id, **ligne.dict())
        db.add(nouvelle_ligne)
    db.commit()

    return nouvelle

@app.get("/factures/", response_model=list[FactureResponse])
def lister_factures(db: Session = Depends(get_db)):
    return db.query(FactureDB).all()


@app.get("/factures/{facture_id}", response_model=FactureResponse)
def consulter_facture(facture_id: int, db: Session = Depends(get_db)):
    return db.query(FactureDB).filter(FactureDB.id == facture_id).first()


@app.put("/factures/{facture_id}/statut")
def maj_statut(facture_id: int, update: StatutUpdate, db: Session = Depends(get_db)):
    facture = db.query(FactureDB).filter(FactureDB.id == facture_id).first()
    facture.statut = update.statut
    if update.numero_bc:
        bc = BonDeCommandeDB(facture_id=facture_id, numero_bc=update.numero_bc)
        db.add(bc)
    db.commit()
    return {"id": facture_id, "statut": update.statut}
from orchestrateur import orchestrer_traitement



@app.post("/orchestrer/")
def lancer_orchestration(facture: FactureCreate, db: Session = Depends(get_db)):
    resultat = orchestrer_traitement(facture.dict(), db)
    return resultat

@app.get("/logs/", response_model=list[LogResponse])
def lire_tous_les_logs(db: Session = Depends(get_db)):
    logs = db.query(LogDB).order_by(LogDB.date_creation.desc()).all()
    return logs


@app.get("/logs/{facture_id}", response_model=list[LogResponse])
def lire_logs_facture(facture_id: int, db: Session = Depends(get_db)):
    logs = db.query(LogDB).filter(LogDB.facture_id == facture_id).order_by(LogDB.date_creation).all()
    return logs
from datetime import datetime

@app.post("/factures_rejets/", response_model=FactureRejetResponse)
def creer_facture_rejetee(rejet: FactureRejetCreate, db: Session = Depends(get_db)):
    nouveau_rejet = FactureRejetDB(**rejet.dict(), date_rejet=datetime.now())
    db.add(nouveau_rejet)
    db.commit()
    db.refresh(nouveau_rejet)
    return nouveau_rejet