from sqlalchemy.orm import Session
from models.database_models import LogDB


def enregistrer_log(db: Session, facture_id: int | None, etape: str, niveau: str, message: str):
    log = LogDB(
        facture_id=facture_id,
        etape=etape,
        niveau=niveau,
        message=message
    )
    db.add(log)
    db.commit()