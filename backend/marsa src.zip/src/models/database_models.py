from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from sqlalchemy.dialects.postgresql import JSONB

class FactureDB(Base):
    __tablename__ = "factures"

    id = Column(Integer, primary_key=True, autoincrement=True)
    fournisseur = Column(String(150))
    client = Column(String(150))
    numero_client = Column(String(50))
    numero_facture = Column(String(50), unique=True)
    type_facture = Column(String(30))
    source_fichier = Column(String(255))
    date_import = Column(DateTime)
    numero_abonnement = Column(String(50))
    numero_appel = Column(String(30))
    date_facture = Column(Date)
    mois_facture = Column(String(20))
    periode_debut = Column(Date)
    periode_fin = Column(Date)
    date_limite_paiement = Column(Date)
    montant_ht = Column(Numeric(12, 2))
    montant_tva = Column(Numeric(12, 2))
    montant_ttc = Column(Numeric(12, 2))
    montant_avance_credit = Column(Numeric(12, 2))
    montant_du = Column(Numeric(12, 2))
    est_duplicata = Column(Boolean, default=False)
    statut = Column(String(30), default="extraite")
    erreur_validation = Column(Text)

    lignes = relationship("LigneFactureDB", back_populates="facture")


class LigneFactureDB(Base):
    __tablename__ = "lignes_facture"

    id = Column(Integer, primary_key=True, autoincrement=True)
    facture_id = Column(Integer, ForeignKey("factures.id"))
    description = Column(String(255))
    categorie = Column(String(50))
    date_debut = Column(Date)
    date_fin = Column(Date)
    montant_ht = Column(Numeric(12, 2))
    date_import = Column(DateTime)

    facture = relationship("FactureDB", back_populates="lignes")


class BonDeCommandeDB(Base):
    __tablename__ = "bons_de_commande"

    id = Column(Integer, primary_key=True, autoincrement=True)
    facture_id = Column(Integer, ForeignKey("factures.id"))
    numero_bc = Column(String(50))


class LogDB(Base):
    __tablename__ = "logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    facture_id = Column(Integer)
    etape = Column(String(50))
    niveau = Column(String(20))
    message = Column(Text)
    date_creation = Column(DateTime)
    from sqlalchemy.dialects.postgresql import JSONB

class FactureRejetDB(Base):
    __tablename__ = "factures_rejets"

    id = Column(Integer, primary_key=True, autoincrement=True)
    numero_facture = Column(String(50))
    fournisseur = Column(String(150))
    raison = Column(String(255))
    donnees_brutes = Column(JSONB)
    date_rejet = Column(DateTime)